var inputs = document.getElementById('checkbox');
inputs.checked = true
